#!/usr/bin/env python3
"""
Web server for Space Funky B.O.B. Level Editor
Serves level data to the web editor.

Author: Null
"""

import http.server
import socketserver
import json
import os
import sys

# Add lib to path
sys.path.insert(0, os.path.dirname(__file__) + "/lib")

from level_extract import LevelExtractor, LEVEL_CATEGORIES

PORT = 8000
EDITOR_DIR = os.path.dirname(__file__)


class EditorHandler(http.server.SimpleHTTPRequestHandler):
    """Handler for editor requests."""

    def do_GET(self):
        """Handle GET requests."""
        if self.path == "/data.json":
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()

            data = self.generate_editor_data()
            self.wfile.write(json.dumps(data, indent=2).encode())

        elif self.path == "/levels":
            # List available levels
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()

            levels = self.get_level_list()
            self.wfile.write(json.dumps(levels, indent=2).encode())

        elif self.path.startswith("/level/"):
            # Get specific level data
            level_name = self.path[7:]  # Remove /level/
            self.send_response(200)
            self.send_header("Content-type", "application/json")
            self.end_headers()

            level_data = self.get_level_data(level_name)
            self.wfile.write(json.dumps(level_data, indent=2).encode())

        elif self.path == "/":
            self.path = "/index.html"
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        else:
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def generate_editor_data(self):
        """Generate all editor data."""
        # Load ROM
        rom_path = os.path.join(EDITOR_DIR, "..", "B.O.B._edit.smc")

        if os.path.exists(rom_path):
            with open(rom_path, "rb") as f:
                rom = f.read()
            extractor = LevelExtractor(rom)
            levels = extractor.analyze_map_files()
        else:
            levels = []

        return {
            "rom": {
                "path": "B.O.B._edit.smc",
                "size": os.path.getsize(rom_path) if os.path.exists(rom_path) else 0,
            },
            "categories": LEVEL_CATEGORIES,
            "levels": levels,
            "mapWidth": 80,
            "mapHeight": 80,
        }

    def get_level_list(self):
        """Get list of all available levels."""
        levels = []

        # Source MAP files
        map_dir = os.path.join(
            EDITOR_DIR, "..", "Space Funky B.O.B. Source Files", "Disk C"
        )

        if os.path.exists(map_dir):
            for category in LEVEL_CATEGORIES:
                cat_path = os.path.join(map_dir, category)
                if os.path.exists(cat_path):
                    for f in sorted(os.listdir(cat_path)):
                        if f.endswith(".MAP"):
                            levels.append(
                                {
                                    "name": f.replace(".MAP", ""),
                                    "category": category,
                                    "theme": LEVEL_CATEGORIES[category]["theme"],
                                    "path": f"Disk C/{category}/{f}",
                                    "source": "map",
                                }
                            )

        return levels

    def get_level_data(self, level_name):
        """Get data for a specific level."""
        map_dir = os.path.join(
            EDITOR_DIR, "..", "Space Funky B.O.B. Source Files", "Disk C"
        )

        # Find the level
        for category in LEVEL_CATEGORIES:
            cat_path = os.path.join(map_dir, category)
            if os.path.exists(cat_path):
                filepath = os.path.join(cat_path, f"{level_name}.MAP")
                if os.path.exists(filepath):
                    with open(filepath, "rb") as f:
                        data = f.read()

                    # Parse the map data
                    # Format: sparse tile data at offset 0x202
                    tiles = []
                    for i in range(0x202, min(len(data), 0x20000), 1):
                        if data[i] != 0:
                            x = (i - 0x202) % 512
                            y = (i - 0x202) // 512
                            tiles.append({"offset": i, "x": x, "y": y, "tile": data[i]})

                    return {
                        "name": level_name,
                        "category": category,
                        "size": len(data),
                        "tiles": tiles,
                        "width": 512,
                        "height": (len(data) - 0x202) // 512 + 1,
                    }

        return {"error": "Level not found"}


def run_server(port=PORT):
    """Run the editor server."""
    os.chdir(EDITOR_DIR)

    with socketserver.TCPServer(("", port), EditorHandler) as httpd:
        print(f"Space Funky B.O.B. Level Editor")
        print(f"=" * 40)
        print(f"Server running at http://localhost:{port}")
        print(f"Press Ctrl+C to stop")
        httpd.serve_forever()


if __name__ == "__main__":
    run_server()
