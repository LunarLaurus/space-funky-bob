#!/usr/bin/env python3
"""
ROM Parser for Space Funky B.O.B.
Handles SNES ROM header parsing, pointer analysis, and data extraction.

Author: Null
"""

import struct
import os


class ROMParser:
    """Parser for Space Funky B.O.B. SNES ROM."""

    # SNES ROM header offsets (at 0x7FC0 for LoROM)
    HEADER_OFFSET = 0x7FC0

    # Known constants from source analysis
    LEVEL_MAP_SIZE = 8192 * 2  # 16KB per level

    def __init__(self, rom_path):
        """Initialize parser with ROM file."""
        self.rom_path = rom_path
        self.rom_data = None
        self.header = {}
        self.load_rom()

    def load_rom(self):
        """Load ROM file into memory."""
        with open(self.rom_path, "rb") as f:
            self.rom_data = f.read()

        self.parse_header()

    def parse_header(self):
        """Parse SNES ROM header."""
        header_data = self.rom_data[self.HEADER_OFFSET : self.HEADER_OFFSET + 32]

        self.header = {
            "title": bytes([b for b in header_data[0:21] if b > 0])
            .decode("ascii", errors="ignore")
            .strip(),
            "makeup": header_data[21],
            "type": header_data[22],
            "size_code": header_data[23],
            "sram_size": header_data[24],
            "destination": header_data[25],
            "fixed": header_data[26],
            "version": header_data[27],
            "checksum_complement": struct.unpack("<H", header_data[28:30])[0],
            "checksum": struct.unpack("<H", header_data[30:32])[0],
            "rom_size": 2 ** (header_data[23] - 10) if header_data[23] >= 10 else 0,
            "has_smc_header": len(self.rom_data) % 512 == 0
            and len(self.rom_data) > 1024 * 1024,
        }

        # ROM offset (skip SMC header if present)
        self.rom_offset = 512 if self.header["has_smc_header"] else 0

    def get_info(self):
        """Get ROM information."""
        return {
            "name": self.header["title"],
            "size": len(self.rom_data),
            "rom_size_mb": self.header["rom_size"],
            "version": self.header["version"],
            "has_smc_header": self.header["has_smc_header"],
            "checksum": hex(self.header["checksum"]),
            "checksum_complement": hex(self.header["checksum_complement"]),
        }

    def read_byte(self, offset):
        """Read a single byte from ROM."""
        return self.rom_data[offset + self.rom_offset]

    def read_word(self, offset):
        """Read a 16-bit word (little-endian) from ROM."""
        return struct.unpack(
            "<H", self.rom_data[self.rom_offset + offset : self.rom_offset + offset + 2]
        )[0]

    def read_long(self, offset):
        """Read a 24-bit address from ROM."""
        data = self.rom_data[self.rom_offset + offset : self.rom_offset + offset + 3]
        return data[0] | (data[1] << 8) | (data[2] << 16)

    def find_lorom_address(self, snes_addr):
        """
        Convert SNES LoROM address to file offset.
        SNES address: $XXYYYY where XX is bank (0x80-0xFF), YYYY is offset
        """
        bank = (snes_addr >> 16) & 0xFF
        offset = snes_addr & 0xFFFF

        # LoROM mapping: bank 0x80-0xFF maps to 0x00000-0x3FFFF
        # Each 32KB bank is mirrored
        if bank >= 0x80:
            file_offset = (bank - 0x80) * 0x8000 + offset
            if offset >= 0x8000:
                file_offset += 0x8000
            return file_offset
        return None

    def find_snes_address(self, file_offset):
        """
        Convert file offset to SNES LoROM address.
        """
        bank = file_offset // 0x8000
        offset = file_offset % 0x8000
        snes_bank = bank + 0x80
        snes_addr = (snes_bank << 16) | offset
        return snes_addr

    def find_compressed_blocks(self, min_size=256, max_results=100):
        """
        Scan ROM for potential LZ77 compressed blocks.
        Returns list of (offset, compressed_size, decompressed_size) tuples.
        """
        blocks = []

        # Look for patterns at various offsets
        for start_offset in range(0, min(len(self.rom_data), 0x100000), 1):
            # Try different sizes
            for size in [256, 512, 1024, 2048, 4096, 8192, 16384]:
                if start_offset + 3 + size > len(self.rom_data):
                    break

                # Try decompressing
                try:
                    from .lz77 import LZ77

                    compressed = self.rom_data[start_offset : start_offset + 3 + size]
                    decompressed = LZ77.decompress(compressed, size * 4)

                    # Check if decompression was successful
                    if len(decompressed) >= size:
                        # Check if there's a reasonable compression ratio
                        ratio = len(decompressed) / len(compressed)
                        if ratio > 1.5:
                            blocks.append(
                                {
                                    "offset": start_offset,
                                    "compressed_size": len(compressed),
                                    "decompressed_size": len(decompressed),
                                    "ratio": ratio,
                                    "snes_addr": self.find_snes_address(start_offset),
                                }
                            )
                            break
                except:
                    pass

        # Sort by size and return top results
        blocks.sort(key=lambda x: x["decompressed_size"], reverse=True)
        return blocks[:max_results]

    def extract_data(self, offset, size):
        """Extract raw data from ROM."""
        return self.rom_data[self.rom_offset + offset : self.rom_offset + offset + size]

    def find_level_pointers(self):
        """
        Attempt to find level data pointers.
        Based on known level size of 16KB (0x4000).
        """
        pointers = []

        # Search for common pointer patterns
        # Level pointers typically in certain ROM banks
        for offset in range(0x10000, 0x80000, 2):
            ptr = self.read_word(offset)

            # Valid SNES ROM addresses are 0x8000-0xFFFF
            if 0x8000 <= ptr <= 0xFFFF:
                # Check if it points to likely level data
                file_off = self.find_lorom_address(ptr << 16)
                if file_off and file_off < len(self.rom_data) - self.LEVEL_MAP_SIZE:
                    pointers.append(
                        {
                            "offset": offset,
                            "snes_ptr": hex(ptr),
                            "file_offset": file_off,
                            "snes_addr": self.find_snes_address(file_off),
                        }
                    )

        return pointers[:50]

    def scan_for_patterns(self):
        """
        Scan ROM for interesting patterns and data structures.
        """
        results = {
            "ascii_strings": [],
            "level_pointers": [],
            "compressed_blocks": [],
        }

        # Find ASCII strings
        for i in range(0, len(self.rom_data) - 16, 1):
            try:
                s = self.rom_data[i : i + 16]
                if all(32 <= b < 127 for b in s) and len(s.strip()) > 8:
                    results["ascii_strings"].append(
                        {
                            "offset": i,
                            "string": s.decode("ascii").strip(),
                            "snes_addr": self.find_snes_address(i),
                        }
                    )
            except:
                pass

        return results


def main():
    """Test ROM parser."""
    import sys

    rom_path = "/usr/workspace/space-funky-bob/B.O.B._edit.smc"
    if not os.path.exists(rom_path):
        print(f"ROM not found: {rom_path}")
        return

    parser = ROMParser(rom_path)
    info = parser.get_info()

    print("=== Space Funky B.O.B. ROM Info ===")
    for key, value in info.items():
        print(f"  {key}: {value}")

    # Find compressed blocks
    print("\n=== Scanning for compressed blocks ===")
    blocks = parser.find_compressed_blocks()
    for block in blocks[:10]:
        print(f"  Offset 0x{block['offset']:06X} (SNES: 0x{block['snes_addr']:06X})")
        print(f"    Compressed: {block['compressed_size']} bytes")
        print(f"    Decompressed: {block['decompressed_size']} bytes")
        print(f"    Ratio: {block['ratio']:.1f}x")


if __name__ == "__main__":
    main()
