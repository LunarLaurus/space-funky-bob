#!/usr/bin/env python3
"""
Tileset Extractor for Space Funky B.O.B.
Extracts and converts SNES 4bpp graphics to PNG.

Author: Null
"""

import struct
import os
import sys

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


class TilesetExtractor:
    """Extract SNES 4bpp tilesets."""

    # SNES 4bpp tile format: 8x8 pixels, 4 bits per pixel (16 colors)
    TILE_SIZE = 32  # 8 * 8 * 4 / 8 = 32 bytes per tile

    # Default SNES palette (16 colors)
    DEFAULT_PALETTE = [
        0x00,
        0x11,
        0x33,
        0x55,
        0x77,
        0x99,
        0xBB,
        0xDD,
        0xFF,
        0xF0,
        0xE0,
        0xD0,
        0xC0,
        0xB0,
        0xA0,
        0x90,
    ]

    def __init__(self, rom_data):
        self.rom = rom_data

    def read_tile(self, data, offset):
        """Read a single 8x8 4bpp tile from data."""
        tile = []
        for y in range(8):
            row = []
            # Each row is 4 bytes (plane 0, then plane 1, etc.)
            for plane in range(4):
                byte = data[offset + y + plane * 8]
                for bit in range(8):
                    # Extract bit from each plane
                    color = 0
                    for p in range(4):
                        if data[offset + y + p * 8] & (0x80 >> bit):
                            color |= 1 << p
                    row.append(color)
            tile.append(row)
        return tile

    def read_tile_simple(self, data, offset):
        """Read tile in standard SNES 4bpp format (simpler)."""
        tile = []
        for y in range(8):
            row = []
            # 4-bit plane interleaving
            p0 = data[offset + y]
            p1 = data[offset + y + 8]
            p2 = data[offset + y + 16]
            p3 = data[offset + y + 24]

            for bit in range(7, -1, -1):  # MSB first
                color = (
                    ((p3 >> bit) & 1) << 3
                    | ((p2 >> bit) & 1) << 2
                    | ((p1 >> bit) & 1) << 1
                    | ((p0 >> bit) & 1)
                )
                row.append(color)
            tile.append(row)
        return tile

    def tile_to_bytes(self, tile):
        """Convert tile back to SNES 4bpp format."""
        data = bytearray(self.TILE_SIZE)

        for y in range(8):
            p0 = p1 = p2 = p3 = 0
            for bit in range(8):
                color = tile[y][7 - bit]
                p0 |= (color & 1) << bit
                p1 |= ((color >> 1) & 1) << bit
                p2 |= ((color >> 2) & 1) << bit
                p3 |= ((color >> 3) & 1) << bit

            data[y] = p0
            data[y + 8] = p1
            data[y + 16] = p2
            data[y + 24] = p3

        return bytes(data)

    def extract_tileset(self, offset, num_tiles, tile_size=32):
        """Extract a tileset from ROM."""
        tiles = []
        for i in range(num_tiles):
            tile_offset = offset + i * tile_size
            if tile_offset + tile_size > len(self.rom):
                break
            tile_data = self.rom[tile_offset : tile_offset + tile_size]
            tiles.append(self.read_tile_simple(tile_data, 0))
        return tiles

    def render_tileset_image(self, tiles, tiles_per_row=16, palette=None):
        """Render tileset to a simple image representation."""
        if not tiles:
            return None

        if palette is None:
            # Generate grayscale palette
            palette = [(i * 255 // 15) for i in range(16)]

        tile_size = 8
        rows = (len(tiles) + tiles_per_row - 1) // tiles_per_row

        # Create image data (simple PPM format for now)
        width = tiles_per_row * tile_size
        height = rows * tile_size

        return {
            "width": width,
            "height": height,
            "tiles": tiles,
            "tiles_per_row": tiles_per_row,
            "palette": palette,
        }

    def save_tileset_ppm(self, tiles, output_path, palette=None):
        """Save tileset as PPM image."""
        if not tiles:
            return False

        if palette is None:
            # Generate grayscale palette
            palette = [(i * 255 // 15) for i in range(16)]

        tiles_per_row = 16
        rows = (len(tiles) + tiles_per_row - 1) // tiles_per_row

        width = tiles_per_row * 8
        height = rows * 8

        with open(output_path, "wb") as f:
            # PPM header
            f.write(f"P6\n{width} {height}\n255\n".encode())

            # Image data
            for row in range(rows):
                for y in range(8):
                    for tile_idx in range(tiles_per_row):
                        tile_num = row * tiles_per_row + tile_idx
                        if tile_num < len(tiles):
                            color_idx = tiles[tile_num][y][tile_idx % 8]
                            color = (
                                palette[color_idx] if color_idx < len(palette) else 0
                            )
                            f.write(bytes([color, color, color]))
                        else:
                            f.write(b"\x00\x00\x00")

        return True

    def find_tilesets(self):
        """Scan ROM for potential tileset data."""
        tilesets = []

        # Look for common CHR patterns
        # Tilesets typically have many repeating patterns
        for offset in range(0, len(self.rom) - 256, 1):
            # Check if this looks like tile data (lots of variation)
            data = self.rom[offset : offset + 256]

            # Count unique bytes - tilesets have many unique values
            unique = len(set(data))

            if unique > 50:  # Likely tile data
                tilesets.append(
                    {
                        "offset": offset,
                        "unique_bytes": unique,
                        "snes_addr": (offset // 0x8000 + 0x80) << 16
                        | (offset % 0x8000),
                    }
                )

        return tilesets[:20]


def main():
    """Test tileset extraction."""
    rom_path = "/usr/workspace/space-funky-bob/B.O.B._edit.smc"

    with open(rom_path, "rb") as f:
        rom = f.read()

    extractor = TilesetExtractor(rom)

    print("=== Finding Tilesets ===")
    tilesets = extractor.find_tilesets()
    for t in tilesets[:10]:
        print(
            f"  Offset 0x{t['offset']:06X}: {t['unique_bytes']} unique bytes (SNES: 0x{t['snes_addr']:06X})"
        )


if __name__ == "__main__":
    main()
