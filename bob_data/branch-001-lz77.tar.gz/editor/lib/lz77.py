#!/usr/bin/env python3
"""
LZ77 Compressor/Decompressor for Space Funky B.O.B.
Based on the custom LZ77 variant used in the game.

Format:
  Chunk:
    [1 byte]   Status byte (8 bits, processed MSB first)
    For each bit in status byte:
      If bit == 0:
        [1 byte]   Literal byte
      If bit == 1:
        [2 bytes]  Distance/Length pair (little-endian)
                   Bits 0-10:  Distance (1-2047)
                   Bits 11-15: Length - 3 (effective length 3-34)

Author: Null
"""

import struct
import io


class LZ77:
    """LZ77 compression/decompression for Space Funky B.O.B."""

    @staticmethod
    def decompress(data, max_decompressed_size=None):
        """
        Decompress LZ77 compressed data.

        Args:
            data: bytes object with compressed data
            max_decompressed_size: optional limit on output size

        Returns:
            bytes object with decompressed data
        """
        output = bytearray()
        i = 0

        while i < len(data):
            if max_decompressed_size and len(output) >= max_decompressed_size:
                break

            status = data[i]
            i += 1

            # Process each bit (MSB first)
            for bit in range(8):
                if i >= len(data):
                    break
                if max_decompressed_size and len(output) >= max_decompressed_size:
                    break

                if status & (0x80 >> bit):
                    # Back-reference (compressed)
                    if i + 1 >= len(data):
                        break
                    pair = struct.unpack("<H", data[i : i + 2])[0]
                    i += 2

                    # Extract distance and length
                    length = ((pair >> 11) & 0x1F) + 3  # Bits 11-15 + 3
                    distance = pair & 0x7FF  # Bits 0-10

                    # Copy from output buffer (handle overlapping correctly)
                    for j in range(length):
                        if distance > len(output):
                            break
                        output.append(output[-(distance)])
                else:
                    # Literal byte
                    output.append(data[i])
                    i += 1

        return bytes(output)

    @staticmethod
    def compress(data):
        """
        Compress data using LZ77 format.

        Args:
            data: bytes object to compress

        Returns:
            bytes object with compressed data
        """
        output = bytearray()
        data = list(data)

        pos = 0
        while pos < len(data):
            status = 0
            chunk_data = []  # Store (is_match, data) tuples in order

            # Process up to 8 bytes
            for bit in range(8):
                if pos >= len(data):
                    break

                # Look for match in previous data
                best_match = LZ77._find_match(data, pos, max_length=34)

                if best_match and best_match[1] >= 3:
                    # Use match
                    status |= 0x80 >> bit
                    chunk_data.append(
                        (True, best_match)
                    )  # (is_match, (distance, length))
                    pos += best_match[1]
                else:
                    # Literal
                    chunk_data.append((False, data[pos]))  # (is_match, byte)
                    pos += 1

            output.append(status)

            # Output data in the order they appear in the chunk
            for is_match, item in chunk_data:
                if is_match:
                    distance, length = item
                    # Encode as: length-3 in upper 5 bits, distance in lower 11 bits
                    pair = ((length - 3) << 11) | distance
                    output.extend(struct.pack("<H", pair))
                else:
                    output.append(item)

        return bytes(output)

    @staticmethod
    def _find_match(data, pos, max_length=34):
        """
        Find the longest match in previous data.
        Based on GuyPerfect's reference implementation.

        Returns:
            (distance, length) tuple or None
        """
        if pos == 0:
            return None

        best_dist = 0
        best_length = 0

        # Search back up to 2047 bytes
        max_dist = min(pos, 2047)

        # Maximum possible length based on remaining data
        remaining = len(data) - pos
        if remaining > 0x22:
            remaining = 0x22

        for dist in range(1, max_dist + 1):
            length = 0
            # Match can extend up to remaining bytes, not limited by dist
            while length < remaining:
                if data[pos - dist + length] != data[pos + length]:
                    break
                length += 1

            if length > best_length and length >= 3:
                best_length = length
                best_dist = dist

        if best_length >= 3:
            return (best_dist, best_length)
        return None

        best_dist = 0
        best_length = 0

        # Search back up to 2047 bytes
        max_dist = min(pos, 2047)

        for dist in range(1, max_dist + 1):
            length = 0
            while (
                length < max_length
                and pos + length < len(data)
                and pos - dist + length >= 0
            ):
                if data[pos - dist + length] != data[pos + length]:
                    break
                length += 1

            if length > best_length and length >= 3:
                best_length = length
                best_dist = dist

        if best_length >= 3:
            return (best_dist, best_length)
        return None


def test_decompression():
    """Test the decompressor on known data."""
    # Test with a simple pattern
    test_data = b"Hello World! This is a test of LZ77 decompression."

    compressed = LZ77.compress(test_data)
    decompressed = LZ77.decompress(compressed)

    if decompressed == test_data:
        print("[OK] LZ77 compression/decompression test passed")
        return True
    else:
        print(f"[FAIL] Decompressed data doesn't match!")
        print(f"  Original: {test_data[:50]}")
        print(f"  Decompressed: {decompressed[:50]}")
        return False


def find_lz77_blocks(rom_data, min_size=256):
    """
    Scan ROM for potential LZ77 compressed blocks.

    Args:
        rom_data: bytes object with ROM data
        min_size: minimum size to consider

    Returns:
        list of (offset, compressed_size, decompressed_size) tuples
    """
    blocks = []

    # Look for common LZ77 header patterns
    # Some games use 0x10 followed by size
    for i in range(0, min(len(rom_data), 0x100000), 1):
        # Check for potential LZ77 start (various patterns)
        if rom_data[i] == 0x10 and i + 3 < len(rom_data):
            size = rom_data[i + 1] | (rom_data[i + 2] << 8)
            if 256 <= size <= 65535:
                # Try decompressing
                try:
                    compressed = rom_data[i : i + 3 + size]
                    decompressed = LZ77.decompress(compressed, size * 2)
                    if len(decompressed) >= size:
                        blocks.append((i, size, len(decompressed)))
                except:
                    pass

    return blocks[:50]  # Return top 50


if __name__ == "__main__":
    test_decompression()
